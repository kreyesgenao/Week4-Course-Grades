#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <limits>
using namespace std;

// Read a whole number within the allowed range.
int readInteger(string prompt, int minimum, int maximum)
{
    int value;

    while (true)
    {
        cout << prompt;

        if (cin >> value && value >= minimum && value <= maximum)
        {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return value;
        }

        if (cin.eof())
            exit(0);

        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Please enter a whole number from "
             << minimum << " to " << maximum << ".\n";
    }
}

// Read a valid grade.
double readGrade()
{
    double grade;

    while (true)
    {
        cout << "Enter the grade (0-100): ";

        if (cin >> grade && grade >= 0 && grade <= 100)
        {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return grade;
        }

        if (cin.eof())
            exit(0);

        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cout << "Invalid grade. Please enter a number from 0 to 100.\n";
    }
}

// Determine the letter grade from the average.
char getLetterGrade(double average)
{
    if (average >= 90)
        return 'A';
    else if (average >= 80)
        return 'B';
    else if (average >= 70)
        return 'C';
    else if (average >= 60)
        return 'D';
    else
        return 'F';
}

int main()
{
    vector<string> courseIDs;
    vector<double> grades;
    int choice;

    cout << fixed << setprecision(2);

    cout << "Welcome to the Course Grades Program!\n";
    cout << "Choose option 1 to enter your courses and grades.\n";
    cout << "Then use the menu to view your results.\n";

    // Repeat the menu until the user chooses Exit.
    do
    {
        cout << "\n========== Course Grades Menu ==========\n";
        cout << "1. Enter Number of Courses\n";
        cout << "2. Display a Specific Course and Grade\n";
        cout << "3. Display All Courses and Grades\n";
        cout << "4. Display Overall Average and Letter Grade\n";
        cout << "5. Exit\n";

        choice = readInteger("Enter your choice (1-5): ", 1, 5);

        switch (choice)
        {
            case 1:
            {
                int numberOfCourses = readInteger(
                    "How many courses do you want to enter (1-100)? ",
                    1, 100
                );

                // Replace previously entered courses.
                courseIDs.clear();
                grades.clear();

                for (int i = 0; i < numberOfCourses; i++)
                {
                    string courseID;

                    cout << "\nCourse " << i + 1 << ":\n";
                    cout << "Enter the course ID (example: CSC101): ";

                    if (!(cin >> courseID))
                        return 0;

                    cin.ignore(
                        numeric_limits<streamsize>::max(), '\n'
                    );

                    courseIDs.push_back(courseID);
                    grades.push_back(readGrade());
                }

                cout << "\nYour courses and grades have been saved.\n";
                break;
            }

            case 2:
            {
                if (courseIDs.empty())
                {
                    cout << "Please choose option 1 to enter courses first.\n";
                    break;
                }

                string searchID;
                bool found = false;

                cout << "Enter the course ID you want to find: ";

                if (!(cin >> searchID))
                    return 0;

                cin.ignore(numeric_limits<streamsize>::max(), '\n');

                // Search for the requested course.
                for (size_t i = 0; i < courseIDs.size(); i++)
                {
                    if (courseIDs[i] == searchID)
                    {
                        cout << "Course ID: " << courseIDs[i] << '\n';
                        cout << "Grade: " << grades[i] << '\n';
                        found = true;
                    }
                }

                if (!found)
                    cout << "That course ID was not found.\n";

                break;
            }

            case 3:
            {
                if (courseIDs.empty())
                {
                    cout << "Please choose option 1 to enter courses first.\n";
                    break;
                }

                cout << "\n"
                     << left << setw(20) << "Course ID"
                     << "Grade\n";
                cout << "------------------------------\n";

                for (size_t i = 0; i < courseIDs.size(); i++)
                {
                    cout << left << setw(20) << courseIDs[i]
                         << grades[i] << '\n';
                }

                break;
            }

            case 4:
            {
                if (grades.empty())
                {
                    cout << "Please choose option 1 to enter courses first.\n";
                    break;
                }

                // Calculate the average using the actual course count.
                double total = 0;

                for (size_t i = 0; i < grades.size(); i++)
                    total += grades[i];

                double average = total / grades.size();

                cout << "\nAverage Grade: " << average << '\n';
                cout << "Letter Grade: "
                     << getLetterGrade(average) << '\n';

                break;
            }

            case 5:
                cout << "Thank you for using the program. Goodbye!\n";
                break;
        }

    } while (choice != 5);

    return 0;
}